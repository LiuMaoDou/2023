# How to use this tool


## Steps

  - Put the device IP, SSH username, SSH password and the commands into **config.xlsx** in config folder.

  - If you have quite a lot of commands to check from a device, you can create one txt file named by the IP of this device and put the commands into it.

  - Highly recommand to run py file in cmd or powershell(and the CLI backgroud color should be *black*, thus tools can show different color when you running the commands.)

  - The outcome will be saved in outcome folder, and the SSH connection situation will also be saved.


## Requirements

  - Make sure you have Python3 installed in your laptop.

  - Please install packages in requirements.txt, mainly **pandas** and **paramiko**.

     - You may choose to install all the packages by `pip install -r requirements.txt`


## Some instructions

  - Tool support three level Jumper, but the first Jumper better a SSH method.

  - Tool also support some some interactive operation, like some `yes` or `no` choice.

  - Coroutine is a better way than multithread, but i'm not quite skilled in this part, later on maybe i will try it and refactor the concurrence py file.

  - The quality of Telnet package in python is literally poor, you have to define the buffer time of each command yourself(each command has different outcome thus time interval between two commands should be different), so better choose SSH method.

***JUST enjoy yourself! ^_^***
