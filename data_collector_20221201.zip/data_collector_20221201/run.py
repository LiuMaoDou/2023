# -*- coding:utf-8 -*-
'''
@author:    Liu Tong
@contact:   liutong14@huawei.com
@software:  python 3.5 or higher
@file:      run.py
@time:      2020.07.20
@desc:      A CLI tool for running commands.
@version:   1.0
'''
from utils import *

if __name__ == '__main__':
    #----------------------------------------------------------------------------------
    #configInitialize()         #generate the txt file for each NE to contain commands.
    #----------------------------------------------------------------------------------
    assemble()                  #Run the commands
    #assembleCon()
    #----------------------------------------------------------------------------------
    #configTest()
    #assembleTest()
    pass

