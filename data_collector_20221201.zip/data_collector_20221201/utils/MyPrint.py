import sys
import ctypes

class MyPrint(object):
    def __init__(self):
        pass

    @staticmethod
    def set_cmd_text_color(color):
        handle = ctypes.windll.kernel32.GetStdHandle(-11)
        return ctypes.windll.kernel32.SetConsoleTextAttribute(handle, color)
    #green
    @staticmethod
    def Green(content):
        MyPrint.set_cmd_text_color(0x0a)
        sys.stdout.write(content + '\n')
        MyPrint.set_cmd_text_color(0x0c | 0x0a | 0x09)
    #red
    @staticmethod
    def Red(content):
        MyPrint.set_cmd_text_color(0x0c)
        sys.stdout.write(content + '\n')
        MyPrint.set_cmd_text_color(0x0c | 0x0a | 0x09)
    #blue
    @staticmethod
    def Blue(content):
        MyPrint.set_cmd_text_color(0x09)
        sys.stdout.write(content + '\n')
        MyPrint.set_cmd_text_color(0x0c | 0x0a | 0x09)
    #yellow
    @staticmethod
    def Yellow(content):
        MyPrint.set_cmd_text_color(0x0e)
        sys.stdout.write(content + '\n')
        MyPrint.set_cmd_text_color(0x0c | 0x0a | 0x09)


