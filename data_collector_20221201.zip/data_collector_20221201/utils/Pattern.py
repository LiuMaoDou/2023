import re
from enum import Enum, unique

@unique
class Pattern(Enum):
    #------------------------------------------------
    neFlag              = re.compile(
                            r'^([<\[])?(?(1).+[>\]]\s?[$#]?|[^#$%^<>=\(\)\s]+\s?[#$%>])\s*$'
                        )

    nebyteFlag          = re.compile(
                            rb'^([<\[])?(?(1).+[>\]]\s?[$#]?|[^#$%^<>=\(\)\s]+\s?[#$%>])\s*$'
                        )


    #------------------------------------------------
    moreFlag            = re.compile(
                            r'-.*more.*-', re.I
                        )
    morebyteFlag        = re.compile(
                            rb'-.*more.*-',re.I
                        )
    #------------------------------------------------
    continueFlag        = re.compile(
                            r'Press any key to continue \(Q to quit\)'
                        )
    continuebyteFlag    = re.compile(
                            rb'Press any key to continue \(Q to quit\)'
                        )
    #------------------------------------------------
    loginFlag           = re.compile(
                            r'^.*(?:login|username):$', re.I
                        )
    loginbyteFlag       = re.compile(
                            rb'^.*(?:login|username):$', re.I
                        )
    #------------------------------------------------
    passordFlag         = re.compile(
                            r'^.*password:$', re.I
                        )
    passordbyteFlag     = re.compile(
                            rb'^.*password:$', re.I
                        )
    #------------------------------------------------
    pwdChangeFlag       = re.compile(
                            r'The password needs to be changed\. Change now\? \[Y/N\]:'
                        )
    pwdChangebyteFlag   = re.compile(
                            rb'The password needs to be changed\. Change now\? \[Y/N\]:'
                        )
    #------------------------------------------------
    firstSshFlag        = re.compile(
                            r'Are you sure you want to continue connecting \(yes/no(?:/\[fingerprint\])?\)\?'
                        )
    firstSshbyteFlag    = re.compile(
                            rb'Are you sure you want to continue connecting \(yes/no(?:/\[fingerprint\])?\)\?'
                        )
    #------------------------------------------------

    displayNextFlag     = re.compile(r'Are you sure to display next \[Y/N\]:')

    displayNextbyteFlag = re.compile(rb'Are you sure to display next \[Y/N\]:')


    #------------------------------------------------

    yes_no_Flag         = re.compile(
                            r'\(yes/no(?:/\[fingerprint\])?\)'
                        )
    yes_no_byteFlag     = re.compile(
                            rb'\(yes/no(?:/\[fingerprint\])?\)'
                        )
    #------------------------------------------------
    Y_N_Flag            = re.compile(
                            r'\[Y/N\]:'
                        )
    Y_N_byteFlag        = re.compile(
                            rb'\[Y/N\]:'
                        )
    #------------------------------------------------
    Y_N_C_Flag          = re.compile(
                            r'\[Y\(yes\)/N\(no\)/C\(cancel\)\]:'
                        )
    Y_N_C_byteFlag      = re.compile(
                            rb'\[Y\(yes\)/N\(no\)/C\(cancel\)\]:'
                        )
    #------------------------------------------------

    Y_N_F_Flag          = re.compile(r'\(yes/no/\[fingerprint\]\)\?')

    Y_N_F_byteFlag      = re.compile(rb'\(yes/no/\[fingerprint\]\)\?')

    #------------------------------------------------

    neErrorFlag         = re.compile(
                            r"Error:(?:\s+)?"
                            r"(?:(?:Incomplete|Unrecognized) command found at '\^' position\.|"
                            r"The specified \S+ does not exist\.|"
                            r"The command must be executed singly, "
                            r"please commit uncommitted configuration first|"
                            r"Bad command\.|Invalid parameter\.|.+)?"
                        )
    neErrorbyteFlag     = re.compile(
                            rb"Error:(?:\s+)?"
                            rb"(?:(?:Incomplete|Unrecognized) command found at '\^' position\.|"
                            rb"The specified \S+ does not exist\.|"
                            rb"The command must be executed singly, "
                            rb"please commit uncommitted configuration first|"
                            rb"Bad command\.|Invalid parameter\.|.+)?"
                        )
    neWarningFlag       = re.compile(
                            r'Warning:(?:\s+)?'
                            r'(?:The current configuration will be written to the device\.|.+)?'
                        )
    neWarningbyteFlag   = re.compile(
                            rb'Warning:(?:\s+)?'
                            rb'(?:The current configuration will be written to the device\.|.+)?'
                        )
    #------------------------------------------------
    sshFlag             = re.compile(
                            r'ssh \S+@(\d{1,3}(?:\.\d{1,3}){3})'
                        )
    sshbyteFlag         = re.compile(
                            rb'ssh \S+@(\d{1,3}(?:\.\d{1,3}){3})'
                        )
    
    sshErrorFlag        = re.compile(
                            r'(?:ssh: connect to host \d{1,3}(?:\.\d{1,3}){3} port 22: '
                            r'(?:Connection timed out|Resource temporarily unavailable|No route to host)|'
                            r'ssh_exchange_identification: Connection closed by remote host|'
                            r'The user has been locked and you cannot log on it\.|'
                            r'Received disconnect from \d{1,3}(?:\.\d{1,3}){3} '
                            r'port 22:2: The connection is closed by SSH Server|'
                            r'Disconnected from \d{1,3}(?:\.\d{1,3}){3} port 22|'
                            r'Unable to negotiate with \d{1,3}(?:\.\d{1,3}){3} port 22:)'
                        )

    sshErrorbyteFlag    = re.compile(
                            rb'(?:ssh: connect to host \d{1,3}(?:\.\d{1,3}){3} port 22: '
                            rb'(?:Connection timed out|Resource temporarily unavailable|No route to host)|'
                            rb'ssh_exchange_identification: Connection closed by remote host|'
                            rb'The user has been locked and you cannot log on it\.|'
                            rb'Received disconnect from \d{1,3}(?:\.\d{1,3}){3} '
                            rb'port 22:2: The connection is closed by SSH Server|'
                            rb'Disconnected from \d{1,3}(?:\.\d{1,3}){3} port 22|'
                            rb'Unable to negotiate with \d{1,3}(?:\.\d{1,3}){3} port 22:)'
                        )
    #------------------------------------------------
    ansiEscape          = re.compile(
                            r'\s*(\x1B(?:[@-Z\\-_]|\[[0-?]*[ -/]*[@-~]))(?:\s*(\1)?\s*)?'
                        )

    #unicodeEscape       = re.compile(r'^([^\u4e00-\u9fa5\u0030-\u0039\u0041-\u005a\u0061-\u007a])$')





    #\\\\\\\\\\\\\\\\\\\\\\\\\\

    huaweiMark = re.compile(r'^<[^:\[\]~@]+>$')

    aluMark = re.compile(r'^\*?[A-Z]:[^:\[\]~@]+#$')

    ciscoMark = re.compile(r'^(?:.+/.+/.+/.+:)?[^:\[\]~@]+#$')

    juniperMark = re.compile(r'^[^:\[\]~]+>$')

    interfaceMain = re.compile(
        r'^\s*((?:\d+GE|GigabitEthernet)\d+/\d+/\d+|Eth-Trunk\d+)'
        r'(?:\(.+\))?\s+up(?:\(s\))?\s+(?:up|down)(?:\(s\))?\s+.+$'
    )

    domain = re.compile(r'^\s+(default0|\S+)\s+Active\s+\d+\s+\d+\s+\d+\s+\d+\s+\d+$')

    device_no = re.compile(r'^(\d+)\s+.+$')

    license_Port = re.compile(r'^(\d+)/\d+/\d+\s+\S+\s+\d+\s+\d+\s+Activated$')


    cisco_phy = re.compile(r'^\s+((?:Te|Gi)\d+/\d+/\d+/\d+)\s+up\s+up.+$')

    alu_phy = re.compile(r'^(\S+/\S+(?:/\S+)?(?:/\S+)?)\s+.+$')

    #\\\\\\\\\\\\\\\\\\\\\\\\\\
