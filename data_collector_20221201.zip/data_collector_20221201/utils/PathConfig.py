import os

path        = os.path.dirname(os.path.dirname(os.path.realpath(__file__)))
pathConfig  = os.path.join(path, 'config')
pathOutcome = os.path.join(path, 'outcome')

