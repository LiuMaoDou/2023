import re
import time
import paramiko

from pprint import pprint

from .Pattern import Pattern
from .MyPrint import MyPrint



class SSH_Client(object):
    def __init__(self, address, username, password, port=22, printStatus=True):
        self._ip = address
        self._client = paramiko.SSHClient()
        self._client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        self._client.connect(
            hostname=address, 
            username=username, 
            password=password,
            port=port, 
            timeout=20, 
            banner_timeout=20, 
            look_for_keys=False, 
            allow_agent=False
        )
        self._shell = self._client.invoke_shell()
        self._print = printStatus

    def bufferReady(self, interval=0.1, timeout=30):
        timeInterval = 0
        
        while True:            
            time.sleep(interval)
            timeInterval += interval
            
            if self._shell.recv_ready() or self._shell.recv_stderr_ready():
                break

            if timeInterval > timeout:
                break
        
        return timeInterval

    def recv_all(self, cmd, cmdBefore, cmdAfter, interval=0.1):
        output = ''

        timeout = 30
        if cmd.startswith('ssh '):
            timeout = 120

        timeInterval = self.bufferReady(interval, timeout)

        if timeInterval >= timeout:
            return output
        
        temp = self._shell.recv(99999).decode(encoding='UTF-8', errors='replace')
        temp = Pattern.ansiEscape.value.sub('', temp)

        if (
            Pattern.moreFlag.value.search(temp.split('\n')[-1]) 
            or Pattern.continueFlag.value.search(temp.split('\n')[-1])
            ):
            output += temp.replace(temp.split('\n')[-1], '')
        else:
            output += temp
        
        #------------------------------------
        
        if self._print:
            #//////////
            print(temp, end='')

        #------------------------------------
        while True:
            #==============================================================
            
            if (
                Pattern.neFlag.value.match(temp.split('\n')[-1].strip())
                or Pattern.loginFlag.value.match(temp.split('\n')[-1].strip())
                or Pattern.passordFlag.value.match(temp.split('\n')[-1].strip())
                ):
                
                break

            #==============================================================
            
            elif (Pattern.yes_no_Flag.value.search(temp.split('\n')[-1]) 
                or Pattern.Y_N_Flag.value.search(temp.split('\n')[-1]) 
                or Pattern.Y_N_C_Flag.value.search(temp.split('\n')[-1])
                ):

                if Pattern.pwdChangeFlag.value.search(temp.split('\n')[-1]):
                        
                    self._shell.send('N\n')
                    temp = self.recv_all(cmd, cmdBefore, cmdAfter, interval)

                    output += temp
                    break

                elif Pattern.displayNextFlag.value.search(temp.split('\n')[-1]):
                    
                    self._shell.send('Y\n')
                    temp = self.recv_all(cmd, cmdBefore, cmdAfter, interval)

                    output += temp
                    break

                elif Pattern.firstSshFlag.value.search(temp.split('\n')[-1]):
                
                    self._shell.send('yes\n')
                    temp = self.recv_all(cmd, cmdBefore, cmdAfter, interval)

                    output += temp
                    break

                elif cmd.strip() == 'display radius-server configuration':
                
                    self._shell.send('Y\n')
                    temp = self.recv_all(cmd, cmdBefore, cmdAfter, interval)
                    
                    output += temp
                    break    

                else:
                    MyPrint.Red(temp.split('\n')[-1])

                    if cmdAfter not in ('Y', 'y', 'N', 'n', 'C', 'c', 'yes', 'no', 'cancel'):
                        
                        yourChoice = ''
                        
                        while True:
                            yourChoice = input(temp.split('\n')[-1])
                            if yourChoice in ('Y', 'y', 'N', 'n', 'C', 'c', 'yes', 'no', 'cancel'):
                                break
                        
                        self._shell.send(yourChoice + '\n')
                        
                        temp = self.recv_all(cmd, cmdBefore, cmdAfter, interval)
                        
                        output += temp
                        break
                    
                    else:
                        break

            #==============================================================
            
            elif (Pattern.moreFlag.value.search(temp.split('\n')[-1]) 
                or Pattern.continueFlag.value.search(temp.split('\n')[-1])
                ):
                
                self._shell.send(' ')
                temp = self.recv_all(cmd, cmdBefore, cmdAfter, interval)

                output += temp
                break
            
            #==============================================================
            '''
            elif timeInterval > 60:

                deviceMark = temp.split('\n')[-1]
                
                self._shell.send(' ')
                deviceMark, temp = self.recv_all(deviceMark, cmd, cmdBefore, cmdAfter, interval)

                output += temp
                break
            '''
            #==============================================================

            #MyPrint.Red('Pending recv_all')

            timeInterval = self.bufferReady(interval, timeout)

            if timeInterval >= timeout:
                return output

            temp = self._shell.recv(99999).decode(encoding='UTF-8', errors='replace')
            temp = Pattern.ansiEscape.value.sub('', temp)

            if (
                Pattern.moreFlag.value.search(temp.split('\n')[-1]) 
                or Pattern.continueFlag.value.search(temp.split('\n')[-1])
                ):
                output += temp.replace(temp.split('\n')[-1], '')
            else:
                output += temp

            #output += temp

            if self._print:
                print(temp, end='')

            #==============================================================

        return output

    def send_command(self, command, cmdBefore, cmdAfter, interval=0.1, sendEnter=True):
        stdout = ''

        command = command.strip()
        
        if command == '':
            return stdout
        
        command += '\n'
        
        #/////////////

        self._shell.send(command)
        stdoutTemp = self.recv_all(command, cmdBefore, cmdAfter, interval)
        stdout += stdoutTemp

        #/////////////

        if sendEnter is True:
            self._shell.send('\n')
            stdoutTemp = self.recv_all(command, cmdBefore, cmdAfter, interval)
            stdout += stdoutTemp
        
        #/////////////

        return stdout

    def run(self, cmds, cmdsJumpers=None, interval=0.1):

        res, stdout = 'Below commands may be wrong:\n', ''

        stdout_temp_before = []
        
        #====================================================================
        
        #self._shell.send('\n')
        
        stdout_temp = self.recv_all('', '', '', interval)
        
        deviceMark = stdout_temp.split('\n')[-1]
        
        #MyPrint.Red(f'deviceMark is |{deviceMark}|')

        #stdout += stdout_temp
        
        #====================================================================
        #if deviceMark:
        
        cmdJumperList = [
            each.strip() for each in cmdsJumpers.split('\n') if each.strip() != ''
        ] if cmdsJumpers is not None else []
        
        cmdList = [each.strip() for each in cmds.split('\n') if each.strip() != '']
        
        combinedCmdList = cmdJumperList + cmdList
        
        for index, cmd in enumerate(combinedCmdList):
            
            #////////////////////////////////////////
            
            if Pattern.neErrorFlag.value.search(stdout_temp):
                res += (cmd + '\n')
            
            if Pattern.sshErrorFlag.value.search(stdout_temp):
                res = 'cannot be connected...@#$%'
                break
            
            #////////////////////////////////////////

            cmdBefore, cmdAfter = '', ''
        
            try:
                cmdBefore = combinedCmdList[index - 1]
                cmdAfter = combinedCmdList[index + 1]
            except IndexError:
                pass
            
            #\\\\\\\\\\\\\\\\\\\\
            _res, _stdout = self.insertCmds(
                'display device', 
                cmdBefore, stdout_temp_before, Pattern.device_no.value, interval, 
                'display device {}', 
                'display version slot {}', 
                'display elabel {}', 
                'display temperature slot {}', 
                'display voltage slot {}'
            )
            res += _res
            stdout += _stdout
            #\\\\\\\\\\\\\\\\\\\\
            _res, _stdout = self.insertCmds(
                'display interface brief main', 
                cmdBefore, stdout_temp_before, Pattern.interfaceMain.value, interval, 
                'display port-queue statistics interface {} outbound', 
                'display interface {}'
            )
            res += _res
            stdout += _stdout
            #\\\\\\\\\\\\\\\\\\\\
            _res, _stdout = self.insertCmds(
                'display domain', 
                cmdBefore, stdout_temp_before, Pattern.domain.value, interval, 
                'display access-user domain {}', 
            )
            res += _res
            stdout += _stdout
            #\\\\\\\\\\\\\\\\\\\\
            _res, _stdout = self.insertCmds(
                'display license resource usage port-basic all', 
                cmdBefore, stdout_temp_before, Pattern.license_Port.value, interval, 
                'display license resource usage port-basic slot {}', 
            )
            res += _res
            stdout += _stdout
            #\\\\\\\\\\\\\\\\\\\\
            _res, _stdout = self.insertCmds(
                'show interfaces brief', 
                cmdBefore, stdout_temp_before, Pattern.cisco_phy.value, interval, 
                'show controllers {} phy', 
            )
            res += _res
            stdout += _stdout
            #\\\\\\\\\\\\\\\\\\\\
            _res, _stdout = self.insertCmds(
                'show port description', 
                cmdBefore, stdout_temp_before, Pattern.alu_phy.value, interval, 
                'show port {} detail', 
            )
            res += _res
            stdout += _stdout
            #\\\\\\\\\\\\\\\\\\\\
            
            if index < len(cmdJumperList):
                stdout_temp = self.send_command(
                    cmd, cmdBefore, cmdAfter, interval, False
                )
            
            else:
                stdout_temp = self.send_command(
                    cmd, cmdBefore, cmdAfter, interval
                ) 
            
            stdout_temp_before = stdout_temp.split('\n')
            #'''
            
            if index == len(cmdJumperList):
                stdout += stdout_temp_before[-1]
                stdout += stdout_temp

            elif index > len(cmdJumperList):
                stdout += stdout_temp
            #'''
            #stdout += stdout_temp

        #////////////////////////////////////////////////////////////////////////

        if res == 'Below commands may be wrong:\n':
            res = 'All commands are executed perfectly'
        elif res == 'cannot be connected...@#$%':
            pass
        else:
            res = res.strip() + '$%^&'
        
        if self._print:
            print('')
        
        return res, stdout

    def close(self):
        self._client.close()



    def insertCmds(self, cmdBeforeTarget, cmdBefore, stdout_temp_before, pattern, interval, *insertedCmds):
        res, stdout = '', ''
        
        if cmdBeforeTarget == cmdBefore:
            
            addedCmdList = []
            cmdParameterSet = set()
            
            for line in stdout_temp_before:
                if pattern.match(line):
                    cmdParameterSet.add(pattern.match(line).group(1))

            for insertedCmd in insertedCmds:
                for each in sorted(list(cmdParameterSet)):
                    addedCmdList.append(insertedCmd.format(each))
            
            for _index, _cmd in enumerate(addedCmdList):
                
                _cmdBefore, _cmdAfter = '', ''
                
                try:
                    _cmdBefore = addedCmdList[_index - 1]
                    _cmdAfter = addedCmdList[_index + 1]
                except IndexError:
                    pass
                
                stdout_temp = self.send_command(_cmd, _cmdBefore, _cmdAfter, interval)
                stdout += stdout_temp
                
                if Pattern.neErrorFlag.value.search(stdout_temp):
                    res += (_cmd + '\n')

        return res, stdout



