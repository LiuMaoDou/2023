import os
import re
import glob
import openpyxl

from pprint import pprint

from collections import OrderedDict
from .MyPrint import MyPrint
from .PathConfig import pathConfig


class Config(object):
    def __init__(self):
        pass

    @staticmethod
    def initialize():
        configXlsx = os.path.join(pathConfig, 'config.xlsx')
        try:
            wb = openpyxl.load_workbook(configXlsx)
            
            ws = wb['config']
            dictKeyList = list()
            
            for indexRow, row in enumerate(ws.rows):
                rowList = list()
                for cell in row:
                    if indexRow == 0 and cell.value is not None and str(cell.value).strip():
                        dictKeyList.append(str(cell.value).strip())
                    elif indexRow >= 1:
                        #print(cell.value)
                        if cell.value is not None and str(cell.value).strip():
                            rowList.append(str(cell.value).strip())
                        else:
                            rowList.append(None)
                if indexRow >= 1 and rowList:
                    configDict = {key: value for key, value in zip(dictKeyList, rowList)}
                    #---------------------------------------------------------
                    #if configDict['Group'] is None:
                    #    configDict['Group'] = str(indexRow)
                    #---------------------------------------------------------
                    
                    if configDict['DestinationIP'] is not None:
                        configTxt = os.path.join(pathConfig, configDict['DestinationIP'] + '.txt')
                        
                        if 'ALU' in configDict['Group'].upper():
                            with open(configTxt, 'w', encoding='utf-8') as f:
                                f.write('environment no more\n')
                                f.write('admin display-config\n')
                                f.write('show service service-using vprn\n')
                                f.write('show lag\n')
                                f.write('show router interface\n')
                                f.write('show router interface detail\n')
                                f.write('show lag detail\n')
                                f.write('show port\n')
                                f.write('show port description\n')
                                f.write('show router isis hostname \n')
                                f.write('show router isis adjacency \n')
                                f.write('show service sap-using\n')
                                f.write('show time\n')
                                f.write('show chassis\n')
                                f.write('show chassis environment\n')
                                f.write('show version\n')
                                f.write('show router ospf neighbor\n')
                                f.write('show router ospf status\n')
                                f.write('show router ospf interface detail\n')
                                f.write('show router isis adjacency\n')
                                f.write('show router isis hostname\n')
                                f.write('show system ntp all\n')
                                f.write('show service service-using vpls\n')
                                f.write('show service service-using epipe\n')
                                f.write('show service service-using cpipe\n')
                                f.write('show service service-using ies\n')
                                f.write('show service active-subscribers\n')
                                f.write('show service service-using vprn\n')
                                f.write('show router bgp neighbor\n')
                                #f.write('show router bgp routes vpn-ipv4 brief\n')
                                f.write('show router bgp summary all\n')
                                f.write('show router ldp session\n')
                                f.write('show aps\n')
                                f.write('show router mpls path\n')
                                f.write('show router mpls lsp detail\n')
                                f.write('show router vrrp instance\n')
                                f.write('show service fdb-mac\n')
                                f.write('show stack\n')
                                f.write('show system lldp\n')
                                f.write('show system lldp neighbor\n')
                                f.write('show service active-subscribers\n')
                                f.write('show router arp\n')
                                f.write('show service sdp-using\n')
                                f.write('show service sdp detail\n')
                                f.write('show service sdp\n')
                                f.write('show chassis environment\n')
                                f.write('show system cpu\n')
                                f.write('show system memory\n')
                                f.write('show system memory-pools\n')
                                f.write('show mda\n')
                                f.write('show mda detail \n')
                                f.write('show card\n')

                        elif 'HUAWEI' in configDict['Group'].upper():
                            with open(configTxt, 'w', encoding='utf-8') as f:

                                f.write('screen-length 0 temporary\n')
                                f.write('display version\n')
                                f.write('display device\n')
                                f.write('display elabel brief\n')
                                f.write('display interface brief\n')
                                f.write('display current-configuration\n')
                                f.write('display clock\n')


                                #f.write('screen-length 0 temporary\n')
                                #f.write('display current-configuration\n')
                                #f.write('display current-configuration | include sysname\n')
                                #f.write('display current-configuration interface LoopBack\n')
                                #f.write('display current-configuration configuration isis\n')
                                #f.write('display current-configuration configuration bgp\n')
                                #f.write('display current-configuration interface\n')
                                #f.write('display version\n')
                                #f.write('display patch-information\n')
                                #f.write('display startup\n')
                                #f.write('display alarm all\n')
                                #f.write('display device\n')
                                #f.write('display device pic-status\n')
                                #f.write('display cpu-usage\n')
                                #f.write('display memory-usage\n')
                                #f.write('display temperature\n')
                                #f.write('display voltage\n')
                                #f.write('display elabel\n')
                                #f.write('display elabel brief\n')
                                #f.write('display msdp brief\n')
                                #f.write('display health\n')
                                #f.write('display esn\n')
                                #f.write('display fan\n')
                                #f.write('display power\n')
                                #f.write('display board-power\n')
                                #f.write('display switchover state\n')
                                #f.write('display mpu-switch-cause\n')
                                #f.write('display application-apperceive\n')
                                #f.write('display license\n')
                                #f.write('display license verbose\n')
                                #f.write('display license resource usage\n')
                                #f.write('display license resource usage port-basic all\n')
                                #f.write('display controller\n')
                                #f.write('display aps group\n')
                                #f.write('display interface\n')
                                #f.write('display interface brief\n')
                                ##f.write('display interface brief\n')
                                #f.write('display port-mirroring interface\n')
                                #f.write('display ip interface brief\n')
                                #f.write('display ipv6 interface\n')
                                #f.write('display optical-module brief\n')
                                #f.write('display interface ethernet brief\n')
                                #f.write('display interface main\n')
                                #f.write('display interface brief main\n')
                                #f.write('display tcp status\n')
                                #f.write('display ipv6 neighbors\n')
                                #f.write('display ipv6 statistics\n')
                                #f.write('display icmpv6 statistics\n')
                                #f.write('display link neighbor all\n')
                                #f.write('display fib statistics all\n')
                                #f.write('display ipv6 fib statistics all\n')
                                #f.write('display ospfv3 interface\n')
                                #f.write('display ospfv3 peer\n')
                                #f.write('display ospf peer\n')
                                #f.write('display ospf brief\n')
                                #f.write('display ospf peer brief\n')
                                #f.write('display ospf interface\n')
                                #f.write('display ospf interface verbose\n')
                                #f.write('display ospf interface all\n')
                                #f.write('display isis peer\n')
                                #f.write('display isis brief\n')
                                #f.write('display isis peer verbose\n')
                                #f.write('display isis interface\n')
                                #f.write('display isis interface verbose\n')
                                #f.write('display isis interface traffic-eng verbose\n')
                                #f.write('display isis error\n')
                                #f.write('display isis ldp-sync interface\n')
                                #f.write('display bgp peer verbose\n')
                                #f.write('display bgp labeled peer verbose\n')
                                #f.write('display bgp vpnv4 all peer verbose\n')
                                #f.write('display bgp vpnv6 all peer verbose\n')
                                #f.write('display bgp vpn-target peer verbose\n')
                                #f.write('display bgp link-state unicast peer verbose\n')
                                #f.write('display bgp sr-policy peer verbose\n')
                                #f.write('display bgp sr-policy ipv6 peer verbose\n')
                                #f.write('display bgp l2vpn-ad peer verbose\n')
                                #f.write('display bgp ipv6 peer verbose\n')
                                #f.write('display bgp evpn peer verbose\n')
                                #f.write('display bgp routing-table statistics\n')
                                #f.write('display bgp ipv6 routing-table statistics\n')
                                #f.write('display bgp vpnv4 all routing-table statistics\n')
                                #f.write('display bgp vpnv6 all routing-table statistics\n')
                                #f.write('display bgp evpn all routing-table statistics\n')
                                #f.write('display bgp ipv6 routing-table statistics label\n')
                                #f.write('display bgp labeled routing-table statistics\n')
                                #f.write('display bgp routing-table label statistics\n')
                                #f.write('display bgp update-peer-group\n')
                                #f.write('display bgp ipv6 update-peer-group\n')
                                #f.write('display bgp vpnv4 all update-peer-group\n')
                                #f.write('display bgp vpnv6 all update-peer-group\n')
                                #f.write('display ip routing-table statistics\n')
                                #f.write('display ipv6 routing-table statistics\n')
                                #f.write('display ip routing-table 0.0.0.0\n')
                                #f.write('display ip routing-table 0.0.0.0 verbose\n')
                                #f.write('display ip routing-table all-vpn-instance statistics\n')
                                #f.write('display ipv6 routing-table ::\n')
                                #f.write('display ipv6 routing-table :: verbose\n')
                                #f.write('display ipv6 routing-table all-vpn-instance statistics\n')
                                #f.write('display lldp neighbor\n')
                                #f.write('display lldp neighbor brief\n')
                                #f.write('display eth-trunk\n')
                                #f.write('display ntp sessions\n')
                                #f.write('display ntp status\n')
                                #f.write('display ntp-service status\n')
                                #f.write('display ntp-service sessions\n')
                                #f.write('display tunnel-info statistics\n')
                                #f.write('display mpls ldp\n')
                                #f.write('display mpls ldp peer\n')
                                #f.write('display mpls ldp peer verbose\n')
                                #f.write('display mpls ldp interface\n')
                                #f.write('display mpls ldp peer statistics\n')
                                #f.write('display mpls ldp adjacency\n')
                                #f.write('display mpls ldp lsp statistics\n')
                                #f.write('display mpls mldp lsp statistics\n')
                                #f.write('display mpls l2vc brief\n')
                                #f.write('display mpls static-l2vc brief\n')
                                #f.write('display mpls switch-l2vc brief\n')
                                #f.write('display mpls l2vc\n')
                                #f.write('display mpls rsvp-te interface\n')
                                #f.write('display mpls rsvp-te peer\n')
                                ##f.write('display mpls te protection tunnel all\n')
                                #f.write('display ospf ldp interface all\n')
                                #f.write('display isis ldp interface\n')
                                #f.write('display vsi\n')
                                #f.write('display mpls l2vc\n')
                                #f.write('display vsi verbose\n')
                                #f.write('display vpls connection verbose\n')
                                #f.write('display bfd statistics\n')
                                #f.write('display bfd session all\n')
                                #f.write('display bfd session all verbose\n')
                                #f.write('display ip vpn-instance\n')
                                #f.write('display ip vpn-instance verbose\n')
                                #f.write('display bgp peer\n')
                                #f.write('display bgp ipv6 peer\n')
                                #f.write('display bgp vpnv4 all peer\n')
                                #f.write('display bgp vpnv6 all peer\n')
                                #f.write('display bgp evpn peer\n')
                                #f.write('display mpls ldp peer all\n')
                                #f.write('display mpls ldp session all\n')
                                #f.write('display mpls ldp session verbose\n')
                                #f.write('display mpls te tunnel-interface last-error\n')
                                #f.write('display mpls te tunnel-interface\n')
                                #f.write('display mpls lsp statistics\n')
                                #f.write('display mpls mldp lsp p2mp\n')
                                #f.write('display router id\n')
                                #f.write('display clock\n')
                                #f.write('display clock config\n')
                                #f.write('display clock source\n')
                                #f.write('display clock source freq-deviation\n')
                                #f.write('display ptp all\n')
                                #f.write('display ptp all config\n')
                                #f.write('display ptp-adaptive all\n')
                                #f.write('display vlan\n')
                                #f.write('display vlan brief\n')
                                #f.write('display stp\n')
                                #f.write('display stp brief\n')
                                #f.write('display stp region-configuration\n')
                                #f.write('display vrrp\n')
                                #f.write('display vrrp statistics\n')
                                #f.write('display pim neighbor\n')
                                #f.write('display pim interface\n')
                                #f.write('display pim routing-table brief\n')
                                #f.write('display pim all-instance routing-table brief\n')
                                #f.write('display pim all-instance neighbor\n')
                                #f.write('display igmp all-instance group\n')
                                #f.write('display igmp interface\n')
                                #f.write('display igmp group\n')
                                #f.write('display igmp-snooping configuration\n')
                                #f.write('display multicast ipv6 forwarding-table statistics\n')
                                #f.write('display domain\n')
                                #f.write('display access-user\n')
                                #f.write('display max-onlineusers\n')
                                #f.write('display access-user slot\n')
                                #f.write('display access-user online-total-number\n')
                                #f.write('display aaa statistics\n')
                                #f.write('display bas-interface\n')
                                #f.write('display dhcp-server group\n')
                                #f.write('display l2-multicast-channel\n')
                                #f.write('display radius-server configuration\n')
                                #f.write('display ip pool\n')
                                #f.write('display ip-pool pool-usage\n')
                                #f.write('display mac-address summary\n')
                                #f.write('display vrrp\n')
                                #f.write('display vrrp brief\n')
                                #f.write('display vrrp admin-vrrp\n')
                                #f.write('display sr-te policy\n')
                                #f.write('display srv6-te policy\n')
                                #f.write('display remote-backup-service\n')
                                #f.write('display remote-backup-profile\n')
                                #f.write('display nat instance\n')
                                #f.write('display nat session-table size\n')
                                #f.write('display service-location\n')
                                #f.write('display nat statistics payload verbose\n')
                                #f.write('display ipsec statistics\n')
                                #f.write('display ipsec sa\n')
                                #f.write('display users\n')

                        elif 'JUNIPER' in configDict['Group'].upper():
                            with open(configTxt, 'w', encoding='utf-8') as f:
                                f.write('show configuration | no-more\n')
                                f.write('show version | no-more\n')
                                f.write('show chassis fan | no-more\n')
                                f.write('show system uptime | no-more\n')
                                f.write('show interfaces | no-more\n')
                                f.write('show interfaces terse | no-more\n')
                                f.write('show interfaces extensive | no-more\n')
                                f.write('show ldp neighbor | no-more\n')

                        elif 'CISCO' in configDict['Group'].upper():
                            with open(configTxt, 'w', encoding='utf-8') as f:
                                f.write('terminal length 0\n')
                                f.write('show running-config\n')
                                f.write('show running-config | include hostname\n')
                                f.write('show version\n')
                                f.write('show processes cpu\n')
                                f.write('show processes memory\n')
                                f.write('show license usage\n')
                                f.write('show led\n')
                                f.write('show redundancy\n')
                                f.write('show interfaces\n')
                                f.write('show ipv6 interface\n')
                                f.write('show ospf\n')
                                f.write('show ospf interface\n')
                                f.write('show ospf neighbor\n')
                                f.write('show ip ospf neighbor\n')
                                f.write('show ip ospf interface\n')
                                f.write('show ip ospf\n')
                                f.write('show ip ospf neighbor detail\n')
                                f.write('show isis hostname\n')
                                f.write('show isis adjacency\n')
                                f.write('show isis interface\n')
                                f.write('show isis neighbors\n')
                                f.write('show adjacency summary\n')
                                f.write('show ntp status\n')
                                f.write('show mpls ldp neighbor\n')
                                f.write('show diag details\n')
                                f.write('show bfd session\n')
                                f.write('show ip vrf\n')
                                f.write('show vrf all\n')
                                f.write('show ip bgp summary\n')
                                f.write('show bgp summary\n')
                                f.write('show bgp neighbors\n')
                                f.write('show mpls ldp discovery\n')
                                f.write('show mpls ldp discovery detail\n')
                                f.write('show aps\n')
                                f.write('show vlan\n')
                                f.write('show vrrp detail\n')
                                f.write('show vrrp\n')
                                f.write('show hsrp\n')
                                f.write('show igmp groups detail\n')
                                f.write('show interfaces brief\n')
                                f.write('show cdp neighbors detail\n')
                                f.write('show cdp neighbors\n')
                                f.write('show cdp all\n')
                                f.write('show lldp neighbors detail\n')
                                f.write('show lldp neighbors\n')
                                f.write('show spanning-tree mst\n')
                                f.write('show subscriber session all detail\n')
                    
                    #---------------------------------------------------------
        except:
            MyPrint.Red('Load configuration failed')
            import traceback
            print(traceback.format_exc())

    @staticmethod
    def parserConfig():
        assembleDict = OrderedDict()
        configXlsx = os.path.join(pathConfig, 'config.xlsx')
        configTxtList = glob.glob(os.path.join(pathConfig, '*.txt'))
        try:
            wb = openpyxl.load_workbook(configXlsx)
            ws = wb['config']
            dictKeyList = list()
            
            for indexRow, row in enumerate(ws.rows):
                
                rowList = list()
                
                for cell in row:
                    
                    if indexRow == 0 and cell.value is not None and str(cell.value).strip():
                        dictKeyList.append(str(cell.value).strip())
                    
                    elif indexRow >= 1:
                        if cell.value is not None and str(cell.value).strip():
                            rowList.append(str(cell.value).strip())
                        else:
                            rowList.append(None)
                        #rowList.append(str(cell.value).strip()) if cell.value else rowList.append(None)
                if indexRow >= 1 and rowList:
                    
                    configDict = {key: value for key, value in zip(dictKeyList, rowList)}
                    
                    if configDict['Commands'] is None:
                        configDict['Commands'] = ''
                    #---------------------------------------------------------
                    if configDict['DestinationIP'] is not None:
                    
                        configTxt = os.path.join(pathConfig, configDict['DestinationIP'] + '.txt')
                    
                        if configTxt in configTxtList:
                            configDict['Commands'] = ''
                    
                            with open(configTxt, 'r', encoding='utf-8', errors='replace') as f:
                                for line in f:
                                    configDict['Commands'] += line
                    #---------------------------------------------------------
                    
                    if configDict['Group'] is None:
                        configDict['Group'] = str(indexRow)
                    
                    if configDict['Group'] not in assembleDict:
                        assembleDict[configDict['Group']] = []
                    
                    assembleDict[configDict['Group']].append(configDict)
        except:
        
            MyPrint.Red('Load configuration fail')
            assembleDict = OrderedDict()
            
            import traceback
            print(traceback.format_exc())
        
        return assembleDict


def configTest():
    Config.initialize()
    pprint(Config.parserConfig())

