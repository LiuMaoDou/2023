import os
import openpyxl
from .PathConfig import pathOutcome


class Excel(object):
    def __init__(self, excelname):
        self._excelname = os.path.join(pathOutcome, excelname)
        self._wb = openpyxl.Workbook()

    def writeExcel(self, sheetname, content):
        try:
            ws = self._wb['Sheet']
            self._wb.remove(ws)
        except:
            pass
        self._wb.create_sheet(sheetname, index=0)
        ws = self._wb[sheetname]
        for line in content:
            ws.append(line)

    def setExcel(self):
        thin = openpyxl.styles.Side(border_style='thin')
        mark_fill_dict = {
            '@#$%': openpyxl.styles.PatternFill('solid', fgColor='FF3030'), #红色 
            '%^&*': openpyxl.styles.PatternFill('solid', fgColor='66CD00'), #绿色
            '$%^&': openpyxl.styles.PatternFill('solid', fgColor='EEEE00'), #黄色
            '^&*!': openpyxl.styles.PatternFill('solid', fgColor='1C86EE'), #蓝色
            '!#%&': openpyxl.styles.PatternFill('solid', fgColor='66CDAA'), #草绿
            '~!@#': openpyxl.styles.PatternFill('solid', fgColor='BABABA')  #灰色
        }
        for ws in self._wb.sheetnames:
            ws = self._wb[ws]
            dims = {}
            for row in ws.rows:
                for cell in row:
                    if cell.value:
                        if '\n' in str(cell.value):
                            cell_length = max(len(s) for s in str(cell.value).split('\n'))
                        else:
                            cell_length = len(str(cell.value))
                        try:
                            dims[cell.column_letter] = max(
                                dims.get(cell.column_letter, 0), cell_length)
                        except:
                            dims[cell.column] = max(dims.get(cell.column, 0), cell_length)

                    cell.font = openpyxl.styles.Font(name='Calibri', size=11)
                    cell.border = openpyxl.styles.Border(left=thin, right=thin, top=thin, bottom=thin)
                    cell.alignment = openpyxl.styles.Alignment(wrapText=True)

                    if cell.value and isinstance(cell.value, str):
                        for mark in mark_fill_dict:
                            if cell.value.endswith(mark):
                                cell.fill = mark_fill_dict[mark]
                                cell.value = cell.value[:-4]
                                break
            for col, value in dims.items():
                ws.column_dimensions[col].width = value + value / 5
        self._wb.save(self._excelname)



if __name__ == '__main__':
    print(pathOutcome)

