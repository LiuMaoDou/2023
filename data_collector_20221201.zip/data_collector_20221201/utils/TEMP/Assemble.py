import sys
import time
from pprint import pprint

from .Actuator import Actuator
from .Actuator_con import ActuatorCon, My_queue

from .ExcelProcess import Excel
from .ConfigParser import Config

#----------------------------------------------------------


def suspend(interval=60):
    time.sleep(interval)

def suspendMannal():
    while True:
        mark = input('Just suspend until you enter (QUIT):')
        if mark in ('QUIT', 'quit', 'Q', 'q'):
            break
def stop():
    sys.exit()

#----------------------------------------------------------

def configInitialize():
    Config.initialize()

#----------------------------------------------------------

class exeTime:
    def __init__(self, func):
        self._func = func
    def __call__(self, *args, **kwargs):
        before = time.time()
        result = self._func(*args, **kwargs)
        after = time.time()
        print(
            '------------------------------------------\n'
            'It takes {}s for exectuating commands!\n'
            '------------------------------------------'.format(round(after - before, 2))
        )
        return result

@exeTime
def assemble():
    excel = Excel('oucome' + time.strftime('_%Y-%m-%d-%H-%M-%S', time.localtime()) + '.xlsx')
    assembleDict = Config.parserConfig()
    collectingLogs = [['IP%^&*', 'Collecting Situation%^&*', 'Outcome Line Number%^&*']]
    for group, configList in assembleDict.items():
        #pprint(config)
        for config in configList:
            with Actuator(config) as actuator:
                #try:
                actuator.runCommands()
                collectingLogs.append(actuator.connectOutcome())
                #except KeyboardInterrupt:
                #    excel.writeExcel('outcome', collectingLogs)
                #    excel.setExcel()
                #    stop()
    
    excel.writeExcel('outcome', collectingLogs)
    excel.setExcel()


#------------------------------------------------------
@exeTime
def assembleCon():
    excel = Excel('oucome' + time.strftime('_%Y-%m-%d-%H-%M-%S', time.localtime()) + '.xlsx')
    assembleDict = Config.parserConfig()
    collectingLogs = [['IP%^&*', 'Collecting Situation%^&*', 'Outcome Line Number%^&*']]
    collecting_logs = []
    threads = list()
    for group, configList in assembleDict.items():
        for config in configList:
            threads.append(ActuatorCon(config))
        for thread in threads:
            thread.start()
        for thread in threads:
            thread.join()
        while True:
            time.sleep(0.0001)
            if not My_queue.empty():
                collecting_logs.append(My_queue.get())
            else:
                break
        threads = list()
    

    #print('haaaaaaaaaaaa')
    collectingLogs.extend(collecting_logs)    
    
    excel.writeExcel('outcome', collectingLogs)
    excel.setExcel()

#------------------------------------------------------

def assembleTest():
    assembleDict = Config.parserConfig()
    pprint(assembleDict)


