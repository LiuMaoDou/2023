import re
import time
import paramiko

from pprint import pprint

from .Pattern import Pattern
from .MyPrint import MyPrint


class ConnectError(Exception):
    pass


class NeError(Exception):
    pass


class SSH_Client(object):
    def __init__(self, address, username, password, port=22, printStatus=True):
        self._ip = address
        self._client = paramiko.SSHClient()
        self._client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        self._client.connect(
            hostname=address, 
            username=username, 
            password=password,
            port=port, 
            timeout=20, 
            banner_timeout=20, 
            look_for_keys=False, 
            allow_agent=False
        )
        self._shell = self._client.invoke_shell()
        self._print = printStatus

    def bufferReady(self, interval=0.1):
        while True:
            time.sleep(interval)
            if self._shell.recv_ready() or self._shell.recv_stderr_ready():
                break

    def recv_unit(self, interval):
        temp = ''
        endMark = 0
        while True:
            if (Pattern.neFlag.value.match(temp.split('\n')[-1].strip()) 
                or Pattern.loginFlag.value.match(temp.split('\n')[-1].strip()) 
                or Pattern.passordFlag.value.match(temp.split('\n')[-1].strip())
                or Pattern.pwdChangeFlag.value.search(temp.split('\n')[-1])
                or Pattern.firstSshFlag.value.search(temp.split('\n')[-1])
                or Pattern.yes_no_Flag.value.search(temp.split('\n')[-1]) 
                or Pattern.Y_N_Flag.value.search(temp.split('\n')[-1]) 
                or Pattern.Y_N_C_Flag.value.search(temp.split('\n')[-1])
                or Pattern.moreFlag.value.search(temp.split('\n')[-1]) 
                or Pattern.continueFlag.value.search(temp.split('\n')[-1])
                ):
                endMark = 1
                break
            elif temp.endswith('\r\n') and len(temp) > 300:
                endMark = 2
                break
            #-----------------------------
            elif len(temp) > 9999:
                endMark = 3
                break
            #-----------------------------
            self.bufferReady(interval)
            temp += self._shell.recv(99999).decode(encoding='UTF-8', errors='replace')
            #*******************************************
            temp = Pattern.ansiEscape.value.sub('\r\n', temp)
            #*******************************************
        return temp, endMark

    def recv_all(self, deviceMark, cmdBefore, cmdAfter, interval=0.1):
        output = ''
        temp, endMark = self.recv_unit(interval)
        output += temp
        #------------------------------------
        if Pattern.neFlag.value.match(deviceMark.strip()):
            if Pattern.neErrorFlag.value.search(temp):
                #--------------
                #MyPrint.Blue('++++++++++++++++++++ ' + str(endMark))
                #print(deviceMark)
                #print('======>')
                #print(temp.split('\n')[0])
                #pprint(temp)
                #MyPrint.Blue('====================')
                #--------------
                if self._print:
                    MyPrint.Red(deviceMark.strip() + temp.split('\n')[0].strip())
                #raise NeError('Command Error')
            elif Pattern.neWarningFlag.value.search(temp):
                #--------------
                #MyPrint.Blue('++++++++++++++++++++ ' + str(endMark))
                #print(deviceMark)
                #print('======>')
                #print(temp.split('\n')[0])
                #pprint(temp)
                #MyPrint.Blue('====================')
                #--------------
                if self._print:
                    MyPrint.Yellow(deviceMark.strip() + temp.split('\n')[0].strip())
            else:
                #--------------
                #MyPrint.Blue('++++++++++++++++++++ ' + str(endMark))
                #print(deviceMark)
                #print('======>')
                #print(temp.split('\n')[0])
                #pprint(temp)
                #MyPrint.Blue('====================')
                #--------------
                if self._print:
                    MyPrint.Green(deviceMark.strip() + temp.split('\n')[0].strip())
        
        elif (Pattern.moreFlag.value.search(deviceMark) 
            or Pattern.continueFlag.value.search(deviceMark)
            ):
            if self._print:
                print(deviceMark.strip())
                print(temp.split('\n')[0].strip())
        
        else:
            #--------------
            #MyPrint.Blue('++++++++++++++++++++ ' + str(endMark))
            #print(deviceMark)
            #print('======>')
            #print(temp.split('\n')[0])
            #pprint(temp)
            #MyPrint.Blue('====================')
            #--------------
            if self._print:
                print(deviceMark.strip() + temp.split('\n')[0].strip())

        if endMark == 1:
            for line in temp.split('\n')[1:-1]:
                if line and line != '\r':
                    if self._print:
                        print(line)
        elif endMark == 2:
            for line in temp.split('\n')[1:]:
                if line and line != '\r':
                    if self._print:
                        print(line)
        elif endMark == 3:
            for line in temp.split('\n')[1:-1]:
                if line and line != '\r':
                    if self._print:
                        print(line)
            if self._print:
                print(temp.split('\n')[-1], end='')
        #------------------------------------
        while True:
            #==============================================================
            if Pattern.neFlag.value.match(temp.split('\n')[-1].strip()):
                deviceMark = temp.split('\n')[-1]
                #if len(temp.split('\n')) >= 2 and Pattern.sshErrorFlag.value.search(temp.split('\n')[-2]):
                #if (
                #    len(temp.split('\n')) >= 2 and 
                #    SSH_Client.checkPattern(Pattern.sshErrorFlag.value, temp.split('\n'))
                #    ):
                #    raise ConnectError('Connection failed')
                break
            #==============================================================
            elif (Pattern.loginFlag.value.match(temp.split('\n')[-1].strip())
                or Pattern.passordFlag.value.match(temp.split('\n')[-1].strip())
                ):
                deviceMark = temp.split('\n')[-1]
                #if len(temp.split('\n')) >= 2 and Pattern.sshErrorFlag.value.match(temp.split('\n')[-2]):
                #if (
                #    len(temp.split('\n')) >= 2 and 
                #    #Pattern.sshErrorFlag.value.match(temp.split('\n')[-2])
                #    SSH_Client.checkPattern(Pattern.sshErrorFlag.value, temp.split('\n'))
                #    ):
                #    raise ConnectError('Connection failed')
                break
            #==============================================================
            elif Pattern.pwdChangeFlag.value.search(temp.split('\n')[-1]):
                deviceMark = temp.split('\n')[-1]
                #print(deviceMark + 'N')
                self._shell.send('N\n')
                deviceMark, temp = self.recv_all(deviceMark, cmdBefore, cmdAfter, interval)
                output += temp
                break
            elif Pattern.firstSshFlag.value.search(temp.split('\n')[-1]):
                deviceMark = temp.split('\n')[-1]
                self._shell.send('yes\n')
                deviceMark, temp = self.recv_all(deviceMark, cmdBefore, cmdAfter, interval)
                output += temp
                break
            #==============================================================
            elif (Pattern.yes_no_Flag.value.search(temp.split('\n')[-1]) 
                or Pattern.Y_N_Flag.value.search(temp.split('\n')[-1]) 
                or Pattern.Y_N_C_Flag.value.search(temp.split('\n')[-1])
                ):
                if cmdAfter not in ('Y', 'y', 'N', 'n', 'C', 'c', 'yes', 'no', 'cancel'):
                    deviceMark = temp.split('\n')[-1]
                    yourChoice = ''
                    while True:
                        yourChoice = input(temp.split('\n')[-1])
                        if yourChoice in ('Y', 'y', 'N', 'n', 'C', 'c', 'yes', 'no', 'cancel'):
                            break
                    self._shell.send(yourChoice + '\n')
                    deviceMark, temp = self.recv_all(deviceMark, cmdBefore, cmdAfter, interval)
                    output += temp
                else:
                    deviceMark = temp.split('\n')[-1]
                break
            #==============================================================
            elif (Pattern.moreFlag.value.search(temp.split('\n')[-1]) 
                or Pattern.continueFlag.value.search(temp.split('\n')[-1])
                ):
                deviceMark = temp.split('\n')[-1]
                self._shell.send(' ')
                #print(deviceMark)
                deviceMark, temp = self.recv_all(deviceMark, cmdBefore, cmdAfter, interval)
                output += temp
                break
            #==============================================================
            #/////////

            #elif temp.split('\n')[-1].strip().endswith(deviceMark.strip()):
            #    deviceMark = temp.split('\n')[-1]
            #    self._shell.send('\n')
            #    deviceMark, temp = self.recv_all(deviceMark, cmdBefore, cmdAfter, interval)
            #    output += temp
            #    break

            #/////////
            #==============================================================

            temp, endMark = self.recv_unit(interval)
            output += temp
            #----------------------------
            #MyPrint.Yellow('++++++++++++++++')
            #pprint(temp)
            #MyPrint.Yellow('================')
            #----------------------------
            #------------------------------------
            if endMark == 1:
                for line in temp.split('\n')[:-1]:
                    if line and line != '\r':
                        if self._print:
                            print(line)
            elif endMark == 2:
                for line in temp.split('\n'):
                    if line and line != '\r':
                        if self._print:
                            print(line)
            elif endMark == 3:
                for line in temp.split('\n')[:-1]:
                    if line and line != '\r':
                        if self._print:
                            print(line)
                if self._print:
                    print(temp.split('\n')[-1], end='')
            #------------------------------------
            #==============================================================
        return deviceMark, output

    def send_command(self, command, deviceMark, cmdBefore, cmdAfter, interval=0.1):
        if command.endswith('\n'):
            pass
        else:
            command += '\n'
        self._shell.send(command)
        deviceMark, stdout = self.recv_all(deviceMark, cmdBefore, cmdAfter, interval)
        return deviceMark, stdout

    def run(self, cmds, interval=0.1):

        #\\\\\\\\\\\\\\\\\\\\\\\\\\

        huaweiMark = re.compile(r'^<[^:\[\]~@]+>$')

        aluMark = re.compile(r'^\*?[A-Z]:[^:\[\]~@]+#$')

        ciscoMark = re.compile(r'^(?:.+/.+/.+/.+:)?[^:\[\]~@]+#$')

        juniperMark = re.compile(r'^[^:\[\]~]+>$')

        interfaceMain = re.compile(
            r'^((?:\d+GE|GigabitEthernet)\d+/\d+/\d+)(?:(100M|10G|1G))?\s+up\s+up\s+[1-9\.]+\s+[1-9\.]+%\s+\d+\s+\d+$'
        )

        #\\\\\\\\\\\\\\\\\\\\\\\\\\

        res, stdout, deviceMark = 'Below commands may be wrong:\n', '', ''
        
        #====================================================================
        
        temp, endMark = self.recv_unit(interval)
        
        stdout += temp
        
        while True:
            if Pattern.neFlag.value.match(temp.split('\n')[-1].strip()):
                deviceMark = temp.split('\n')[-1]
                break
            elif Pattern.pwdChangeFlag.value.search(temp.split('\n')[-1]):
                self._shell.send('N\n')
            temp, endMark = self.recv_unit(interval)
            stdout += temp
        
        #====================================================================

        stdout_temp_before = ''

        if deviceMark:
            
            cmdList = cmds.split('\n')

            #pprint(cmdList)
            
            for index, cmd in enumerate(cmdList):
                if cmd.strip():
                    
                    cmdBefore, cmdAfter = '', ''
                    
                    try:
                        cmdBefore = cmdList[index - 1].strip()
                        cmdAfter = cmdList[index + 1].strip()
                    except IndexError:
                        pass

                    #\\\\\\\\\\\\\\\\\\\\

                    '''

                    if cmdBefore == 'Milenium0)':

                        #print('||||||||||||||||||||||||||||||||')
                        #print(f'|{deviceMark}|')

                        addedCmdList = []

                        if huaweiMark.match(deviceMark.strip()):
                            addedCmdList.extend(
                                [
                                    'screen-length 0 temporary', 
                                    'display current-configuration'
                                ]
                            )

                        elif aluMark.match(deviceMark.strip()):
                            addedCmdList.extend(
                                [
                                    'environment no more', 
                                    'admin display-config'
                                ]
                            )

                        elif ciscoMark.match(deviceMark.strip()):
                            addedCmdList.extend(
                                [
                                    'terminal length 0', 
                                    'show running-config'
                                ]
                            )

                        elif juniperMark.match(deviceMark.strip()):
                            addedCmdList.extend(
                                [
                                    'show configuration | no-more', 
                                    'show version | no-more'
                                ]
                            )

                        for _index, _cmd in enumerate(addedCmdList):
                            if _cmd.strip():
                                
                                _cmdBefore, _cmdAfter = '', ''

                                try:
                                    _cmdBefore = addedCmdList[_index - 1].strip()
                                    _cmdAfter = addedCmdList[_index + 1].strip()
                                except IndexError:
                                    pass

                                deviceMark, stdout_temp = self.send_command(
                                    _cmd, deviceMark, _cmdBefore, _cmdAfter, interval
                                )

                                stdout += stdout_temp

                                if Pattern.neErrorFlag.value.search(stdout_temp):
                                    res += (_cmd + '\n')
                    
                    '''
                    
                    #\\\\\\\\\\\\\\\\\\\\

                    if cmdBefore == 'display interface brief main':
                        pass

                    #\\\\\\\\\\\\\\\\\\\\
         
                    deviceMark, stdout_temp = self.send_command(
                        cmd, deviceMark, cmdBefore, cmdAfter, interval
                    )

                    stdout += stdout_temp
                    
                    if Pattern.neErrorFlag.value.search(stdout_temp):
                        res += (cmd + '\n')
                    #//////
                    if Pattern.sshErrorFlag.value.search(stdout_temp):
                        res = 'cannot be connected...@#$%'
                        break
                    #//////
            
            if res == 'Below commands may be wrong:\n':
                res = 'All commands are executed perfectly'
            
            else:
                res = res.strip() + '$%^&'

        return res, stdout

    def close(self):
        self._client.close()


    @staticmethod
    def checkPattern(pattern, temp):
        for line in temp:
            if pattern.match(line) or pattern.search(line):
                return True

        return False

