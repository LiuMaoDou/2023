import os
import time
import queue
import threading
import traceback

from pprint import pprint

from .MyPrint import MyPrint
from .PathConfig import pathOutcome
from .Pattern import Pattern
from .SSH_Client import SSH_Client, ConnectError, NeError
from .Telnet_Client import Telnet_Client

#-----------------------------------------------------
Client_Limiter = threading.BoundedSemaphore(10)
resource_protection = threading.RLock()
My_queue = queue.Queue()
#-----------------------------------------------------

#class ConnectError(Exception):
#    pass


#class NeError(Exception):
#    pass


class ActuatorCon(threading.Thread):
    def __init__(self, config):
        threading.Thread.__init__(self)

        self._group = config['Group']
        self._actuator = None
        self._destinationip = config['DestinationIP']
        #--------------------------
        self._ip = None
        self._username = None
        self._password = None
        self._method = None
        self._port = None
        
        self._commands_jumper = None
        self._commands = None
        
        self._outcome = None
        #--------------------------
        self.__inilize(config)

    def group(self):
        return self._group

    def __inilize(self, config):
        
        if config['Jumper1_IP'] is None:
            self._ip       = config['DestinationIP']
            self._username = config['UserName']
            self._password = config['Password']
            self._method   = config['Method']
            self._port     = config['Port']
            self._commands = config['Commands']
            self._outcome  = [self._ip]
        
        elif config['Jumper1_IP'] is not None:
            self._ip       = config['Jumper1_IP']
            self._username = config['Jumper1_UserName']
            self._password = config['Jumper1_Password']
            self._method   = config['Jumper1_Method']
            self._port     = config['Jumper1_Port']

            if config['Jumper2_IP'] is None:
                if config['Method'].lower() == 'ssh':
                    self._commands_jumper = (
                        f"ssh -p {config['Port']} {config['UserName']}@{config['DestinationIP']}\n" 
                        if config['Port'] is not None 
                        else 
                        f"ssh {config['UserName']}@{config['DestinationIP']}\n" 
                    )
                    self._commands_jumper +=  f"{config['Password']}\n"
                    #self._commands += config['Commands']
                elif config['Method'].lower() == 'telnet':
                    self._commands_jumper = (
                        f"telnet {config['DestinationIP']} {config['Port']}\n" 
                        if config['Port'] is not None 
                        else 
                        f"telnet {config['DestinationIP']}\n"
                    )
                    self._commands_jumper += f"{config['UserName']}\n"
                    self._commands_jumper += f"{config['Password']}\n"
                    #self._commands += config['Commands']

            elif config['Jumper2_IP'] is not None:
                if config['Jumper3_IP'] is None:
                    if config['Jumper2_Method'].lower() == 'ssh':
                        self._commands_jumper = (
                            f"ssh -p {config['Jumper2_Port']} {config['Jumper2_UserName']}@{config['Jumper2_IP']}\n" 
                            if config['Jumper2_Port'] is not None 
                            else 
                            f"ssh {config['Jumper2_UserName']}@{config['Jumper2_IP']}\n" 
                        )
                        self._commands_jumper += f"{config['Jumper2_Password']}\n"
                    elif config['Jumper2_Method'].lower() == 'telnet':
                        self._commands_jumper = (
                            f"telnet {config['Jumper2_IP']} {config['Jumper2_Port']}\n" 
                            if config['Jumper2_Port'] is not None 
                            else 
                            f"telnet {config['Jumper2_IP']}\n" 
                        )
                        self._commands_jumper += f"{config['Jumper2_UserName']}\n"
                        self._commands_jumper += f"{config['Jumper2_Password']}\n"

                    if config['Method'].lower() == 'ssh':
                        self._commands_jumper += (
                            f"ssh -p {config['Port']} {config['UserName']}@{config['DestinationIP']}\n" 
                            if config['Port'] is not None 
                            else 
                            f"ssh {config['UserName']}@{config['DestinationIP']}\n" 
                        )
                        self._commands_jumper +=  f"{config['Password']}\n"
                        #self._commands += config['Commands']
                    elif config['Method'].lower() == 'telnet':
                        self._commands_jumper += (
                            f"telnet {config['DestinationIP']} {config['Port']}\n" 
                            if config['Port'] is not None 
                            else 
                            f"telnet {config['DestinationIP']}\n"
                        )
                        self._commands_jumper += f"{config['UserName']}\n"
                        self._commands_jumper += f"{config['Password']}\n"
                        #self._commands += config['Commands']

                else:
                    if config['Jumper2_Method'].lower() == 'ssh':
                        self._commands_jumper = (
                            f"ssh -p {config['Jumper2_Port']} {config['Jumper2_UserName']}@{config['Jumper2_IP']}\n" 
                            if config['Jumper2_Port'] is not None 
                            else 
                            f"ssh {config['Jumper2_UserName']}@{config['Jumper2_IP']}\n" 
                        )
                        self._commands_jumper += f"{config['Jumper2_Password']}\n"
                    elif config['Jumper2_Method'].lower() == 'telnet':
                        self._commands_jumper = (
                            f"telnet {config['Jumper2_IP']} {config['Jumper2_Port']}\n" 
                            if config['Jumper2_Port'] is not None 
                            else 
                            f"telnet {config['Jumper2_IP']}\n" 
                        )
                        self._commands_jumper += f"{config['Jumper2_UserName']}\n"
                        self._commands_jumper += f"{config['Jumper2_Password']}\n"

                    if config['Jumper3_Method'].lower() == 'ssh':
                        self._commands_jumper += (
                            f"ssh -p {config['Jumper3_Port']} {config['Jumper3_UserName']}@{config['Jumper3_IP']}\n" 
                            if config['Jumper3_Port'] is not None 
                            else
                            f"ssh {config['Jumper3_UserName']}@{config['Jumper3_IP']}\n" 
                        )
                        self._commands_jumper += f"{config['Jumper3_Password']}\n"
                    elif config['Jumper3_Method'].lower() == 'telnet':
                        self._commands_jumper += (
                            f"telnet {config['Jumper3_IP']} {config['Jumper3_Port']}\n" 
                            if config['Jumper3_Port'] is not None 
                            else 
                            f"telnet {config['Jumper3_IP']}\n"
                        )
                        self._commands_jumper += f"{config['Jumper3_UserName']}\n"
                        self._commands_jumper += f"{config['Jumper3_Password']}\n"

                    if config['Method'].lower() == 'ssh':
                        self._commands_jumper += (
                            f"ssh -p {config['Port']} {config['UserName']}@{config['DestinationIP']}\n" 
                            if config['Port'] is not None 
                            else 
                            f"ssh {config['UserName']}@{config['DestinationIP']}\n" 
                        )
                        self._commands_jumper +=  f"{config['Password']}\n"
                        #self._commands += config['Commands']
                    elif config['Method'].lower() == 'telnet':
                        self._commands_jumper += (
                            f"telnet {config['DestinationIP']} {config['Port']}\n" 
                            if config['Port'] is not None 
                            else 
                            f"telnet {config['DestinationIP']}\n"
                        )
                        self._commands_jumper += f"{config['UserName']}\n"
                        self._commands_jumper += f"{config['Password']}\n"
                        #self._commands += config['Commands']

            self._outcome  = [config['DestinationIP']]
            #print(self._commands)
 
    def writeFile(self, stdout):
        file_time = time.strftime('_%Y-%m-%d-%H-%M-%S', time.localtime())
        file_name = os.path.join(pathOutcome, self._group + '_' + self._destinationip + file_time + '.txt')
        with open(file_name, 'w', encoding='utf-8') as f:
            #-------------------------------------------------
            f.write(
                '#' * 90 + '\n' + '#' + ' ' * 88 + '#' + '\n' + '#' + ' ' * 11 + 
                '^_^    A CLI Tool Made By Kelvin, Thanks For Your Support~~    ^_^' + 
                ' ' * 11 + '#' + '\n' + '#' + ' ' * 88 + '#' + '\n' + '#' * 90 + '\n'
            )
            #-------------------------------------------------
            for line in stdout.split('\r\n'):
                f.write(line)
                f.write('\n')
        return file_name

    def run(self):
        with Client_Limiter:
            with resource_protection:
                MyPrint.Blue(
                    '----------------------------------\n' +
                    f'Connecting to {self._destinationip}\n' +
                    '----------------------------------'
                )
            try:
                if self._method.lower() == 'ssh':
                    self._actuator = SSH_Client(self._ip, self._username, self._password, self._port, False)
                
                elif self._method.lower() == 'telnet':
                    self._actuator = Telnet_Client(self._ip, self._username, self._password, self._port, False)
                #with resource_protection:
                #    MyPrint.Blue(
                #        '----------------------------------\n' +
                #        'Connection to {} succeed\n'.format(self._destinationip) +
                #        '----------------------------------'
                #    )
            except:
                self._actuator = None
                self._outcome.extend(['cannot be connected...@#$%', 0])
                with resource_protection:
                    MyPrint.Blue(
                        '----------------------------------\n' +
                        f'Connection to {self._destinationip} failed\n' +
                        '----------------------------------'
                    )

            interval = 0.01 if self._method.lower() == 'ssh' else 2
            if self._actuator:
                try:
                    #print(self._ip)
                    #pprint(self._commands)
                    #print('-------------------------')
                    if self._commands_jumper is not None:
                        _, _ = self._actuator.run(self._commands_jumper, interval)
                    res, stdout = self._actuator.run(self._commands, interval)
                
                #except ConnectError as e:
                #    self._outcome.extend(['cannot be connected...@#$%', 0])
                
                
                except:
                    print(traceback.format_exc())
                
                else:
                    self._outcome.extend([res, len(stdout.split('\r\n'))])
                    with resource_protection:
                        self.writeFile(stdout)

            My_queue.put(self._outcome)
            
            time.sleep(1) if self._method.lower() == 'ssh' else time.sleep(5)
            
            if self._actuator is not None:
                self._actuator.close()
                self._actuator = None
                with resource_protection:
                    MyPrint.Blue(
                        '-------------------------------\n' +
                        f'Connection {self._destinationip} closed\n' + 
                        '-------------------------------'
                    )

