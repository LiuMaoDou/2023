import os
import re
import glob
import openpyxl

from pprint import pprint

from collections import OrderedDict
from .MyPrint import MyPrint
from .PathConfig import pathConfig


class Config(object):
    def __init__(self):
        pass

    @staticmethod
    def initialize():
        configXlsx = os.path.join(pathConfig, 'config.xlsx')
        try:
            wb = openpyxl.load_workbook(configXlsx)
            ws = wb['config']
            dictKeyList = list()
            for indexRow, row in enumerate(ws.rows):
                rowList = list()
                for cell in row:
                    if indexRow == 0 and cell.value is not None and str(cell.value).strip():
                        dictKeyList.append(str(cell.value).strip())
                    elif indexRow >= 1:
                        #print(cell.value)
                        if cell.value is not None and str(cell.value).strip():
                            rowList.append(str(cell.value).strip())
                        else:
                            rowList.append(None)
                if indexRow >= 1 and rowList:
                    configDict = {key: value for key, value in zip(dictKeyList, rowList)}
                    #---------------------------------------------------------
                    #if configDict['Group'] is None:
                    #    configDict['Group'] = str(indexRow)
                    #---------------------------------------------------------
                    if configDict['DestinationIP'] is not None:
                        configTxt = os.path.join(pathConfig, configDict['DestinationIP'] + '.txt')
                        
                        if 'ALU' in configDict['Group'].upper():
                            with open(configTxt, 'w', encoding='utf-8') as f:
                                f.write()

                        elif 'HUAWEI' in configDict['Group'].upper():
                            with open(configTxt, 'w', encoding='utf-8') as f:
                                f.write('screen-length 0 temporary\n')
                                f.write('display current-configuration\n')
                                f.write('display current-configuration | include sysname\n')
                                f.write('display patch-information\n')
                                f.write('display device\n')
                                f.write('display device pic-status\n')
                                f.write('display cpu-usage\n')
                                f.write('display elabel\n')
                                f.write('display memory-usage\n')
                                f.write('display version\n')
                                f.write('display health\n')
                                f.write('display esn\n')
                                f.write('display fan\n')
                                f.write('display power\n')
                                f.write('display license\n')
                                f.write('display license resource usage port-basic all\n')
                                f.write('display interface brief main\n')
                                f.write('display interface brief\n')
                                f.write('display interface\n')
                                f.write('display interface ethernet brief\n')
                                f.write('display ipv6 neighbors\n')
                                f.write('display link neighbor all\n')
                                f.write('display ospfv3 interface\n')
                                f.write('display ospfv3 peer\n')
                                f.write('display ospf peer\n')
                                f.write('display ospf peer brief\n')
                                f.write('display ospf interface\n')
                                f.write('display ospf interface verbose\n')
                                f.write('display ospf interface all\n')
                                f.write('display isis peer\n')
                                f.write('display isis peer verbose\n')
                                f.write('display isis interface verbose\n')
                                f.write('display isis interface traffic-eng verbose\n')
                                f.write('display bgp labeled peer verbose\n')
                                f.write('display bgp vpnv4 all peer verbose\n')
                                f.write('display bgp vpnv6 all peer verbose\n')
                                f.write('display bgp vpn-target peer verbose\n')
                                f.write('display bgp link-state unicast peer verbose\n')
                                f.write('display bgp sr-policy peer verbose\n')
                                f.write('display bgp sr-policy ipv6 peer verbose\n')
                                f.write('display bgp l2vpn-ad peer verbose\n')
                                f.write('display bgp ipv6 peer verbose\n')
                                f.write('display bgp evpn peer verbose\n')
                                f.write('display lldp neighbor\n')
                                f.write('display eth-trunk\n')
                                f.write('display ntp-service status\n')
                                f.write('display mpls ldp peer statistics\n')
                                f.write('display mpls ldp lsp statistics\n')
                                f.write('display mpls l2vc brief\n')
                                f.write('display mpls l2vc\n')
                                f.write('display vsi\n')
                                f.write('display vsi verbose\n')
                                f.write('display bfd statistics\n')
                                f.write('display bfd session all\n')
                                f.write('display ip vpn-instance\n')
                                f.write('display ip vpn-instance verbose\n')
                                f.write('display bgp peer\n')
                                f.write('display bgp vpnv4 all peer\n')
                                f.write('display mpls ldp peer all\n')
                                f.write('display mpls ldp session all\n')
                                f.write('display router id\n')
                                f.write('display clock source\n')
                                f.write('display clock source freq-deviation\n')
                                f.write('display ptp all\n')
                                f.write('display ptp-adaptive all\n')
                                f.write('display clock config\n')
                                f.write('display mpls te tunnel-interface\n')
                                f.write('display vlan\n')
                                f.write('display stp\n')
                                f.write('display stp region-configuration\n')
                                f.write('display vlan brief\n')
                                f.write('display vrrp\n')
                                f.write('display pim interface\n')
                                f.write('display igmp interface\n')
                                f.write('display igmp group\n')
                                f.write('display domain\n')
                                f.write('display mac-address summary\n')
                                f.write('display ip routing-table statistics\n')
                                f.write('display ip routing-table all-vpn-instance statistics\n')
                                f.write('display vrrp brief\n')
                                f.write('display mpls lsp statistics\n')
                                f.write('display sr-te policy\n')
                                f.write('display srv6-te policy\n')

                        elif 'JUNIPER' in configDict['Group'].upper():
                            with open(configTxt, 'w', encoding='utf-8') as f:
                                f.write()

                        elif 'CISCO' in configDict['Group'].upper():
                            with open(configTxt, 'w', encoding='utf-8') as f:
                                f.write()
                    #---------------------------------------------------------
        except:
            MyPrint.Red('Load configuration failed')
            import traceback
            print(traceback.format_exc())

    @staticmethod
    def parserConfig():
        assembleDict = OrderedDict()
        configXlsx = os.path.join(pathConfig, 'config.xlsx')
        configTxtList = glob.glob(os.path.join(pathConfig, '*.txt'))
        try:
            wb = openpyxl.load_workbook(configXlsx)
            ws = wb['config']
            dictKeyList = list()
            
            for indexRow, row in enumerate(ws.rows):
                
                rowList = list()
                
                for cell in row:
                    
                    if indexRow == 0 and cell.value is not None and str(cell.value).strip():
                        dictKeyList.append(str(cell.value).strip())
                    
                    elif indexRow >= 1:
                        if cell.value is not None and str(cell.value).strip():
                            rowList.append(str(cell.value).strip())
                        else:
                            rowList.append(None)
                        #rowList.append(str(cell.value).strip()) if cell.value else rowList.append(None)
                if indexRow >= 1 and rowList:
                    
                    configDict = {key: value for key, value in zip(dictKeyList, rowList)}
                    
                    if configDict['Commands'] is None:
                        configDict['Commands'] = ''
                    #---------------------------------------------------------
                    if configDict['DestinationIP'] is not None:
                    
                        configTxt = os.path.join(pathConfig, configDict['DestinationIP'] + '.txt')
                    
                        if configTxt in configTxtList:
                            configDict['Commands'] = ''
                    
                            with open(configTxt, 'r', encoding='utf-8', errors='replace') as f:
                                for line in f:
                                    configDict['Commands'] += line
                    #---------------------------------------------------------
                    
                    if configDict['Group'] is None:
                        configDict['Group'] = str(indexRow)
                    
                    if configDict['Group'] not in assembleDict:
                        assembleDict[configDict['Group']] = []
                    
                    assembleDict[configDict['Group']].append(configDict)
        except:
        
            MyPrint.Red('Load configuration fail')
            assembleDict = OrderedDict()
            
            import traceback
            print(traceback.format_exc())
        
        return assembleDict


def configTest():
    Config.initialize()
    pprint(Config.parserConfig())

