import time
import telnetlib

from .Pattern import Pattern
from .MyPrint import MyPrint



class Telnet_Client(object):
    def __init__(self, address, username, password, port=23, printStatus=True):
        self._telnet = telnetlib.Telnet()
        self._telnet.open(host=address, port=port)
        self._telnet.read_until(b':', timeout=5)
        self._telnet.write(username.encode('ascii') + b'\n')
        self._telnet.read_until(b'assword:', timeout=5)
        self._telnet.write(password.encode('ascii') + b'\n')

        self._print = printStatus

        time.sleep(2)

        stdout = self._telnet.expect(
            [
                Pattern.nebyteFlag.value, 
                Pattern.pwdChangebyteFlag.value, 
                Pattern.firstSshbyteFlag.value
            ], 
            timeout=5
        )[2].decode(encoding='UTF-8', errors='replace')

        if Pattern.pwdChangeFlag.value.search(stdout.split('\n')[-1]):
            self._telnet.write('N'.encode('ascii') + b'\n')
        
        elif Pattern.firstSshFlag.value.search(stdout.split('\n')[-1]):
            self._telnet.write('yes'.encode('ascii') + b'\n')
        
        elif Pattern.neFlag.value.search(stdout.split('\n')[-1]):
            pass
        
        stdout = self._telnet.expect(
            [
                Pattern.nebyteFlag.value, 
                Pattern.pwdChangebyteFlag.value, 
                Pattern.firstSshbyteFlag.value
            ], 
            timeout=5
        )[2].decode(encoding='UTF-8', errors='replace')

    def send_command(self, command, interval):
        command = command.strip()
        self._telnet.write(command.encode('ascii') + b'\n')
        stdout = self._telnet.expect(
            [
                Pattern.nebyteFlag.value, 
                Pattern.pwdChangebyteFlag.value, 
                Pattern.morebyteFlag.value, 
                Pattern.continuebyteFlag.value, 
                Pattern.loginbyteFlag.value, 
                Pattern.passordbyteFlag.value, 
                Pattern.firstSshbyteFlag.value, 
                Pattern.yes_no_byteFlag.value,
                Pattern.Y_N_byteFlag.value, 
                Pattern.Y_N_C_byteFlag.value
            ], 
            timeout=interval
        )[2].decode(encoding='UTF-8', errors='replace')
        #----------------------------------------------------------
        if Pattern.pwdChangeFlag.value.search(stdout.split('\n')[-1]):
            self._telnet.write('N'.encode('ascii') + b'\n')
            stdout += self._telnet.expect(
                [
                    Pattern.nebyteFlag.value, 
                    Pattern.pwdChangebyteFlag.value, 
                    Pattern.morebyteFlag.value, 
                    Pattern.continuebyteFlag.value, 
                    Pattern.loginbyteFlag.value, 
                    Pattern.passordbyteFlag.value, 
                    Pattern.firstSshbyteFlag.value, 
                    Pattern.yes_no_byteFlag.value,
                    Pattern.Y_N_byteFlag.value, 
                    Pattern.Y_N_C_byteFlag.value
                ], 
                timeout=interval
            )[2].decode(encoding='UTF-8', errors='replace')
        elif Pattern.firstSshFlag.value.search(stdout.split('\n')[-1]):
            self._telnet.write('yes'.encode('ascii') + b'\n')
            stdout += self._telnet.expect(
                [
                    Pattern.nebyteFlag.value, 
                    Pattern.pwdChangebyteFlag.value, 
                    Pattern.morebyteFlag.value, 
                    Pattern.continuebyteFlag.value, 
                    Pattern.loginbyteFlag.value, 
                    Pattern.passordbyteFlag.value, 
                    Pattern.firstSshbyteFlag.value, 
                    Pattern.yes_no_byteFlag.value,
                    Pattern.Y_N_byteFlag.value, 
                    Pattern.Y_N_C_byteFlag.value
                ], 
                timeout=interval
            )[2].decode(encoding='UTF-8', errors='replace')
        #----------------------------------------------------------
        data = stdout.split('\n')
        while (Pattern.moreFlag.value.search(data[-1]) or Pattern.continueFlag.value.search(data[-1])):
            self._telnet.write(b' ')
            #tmp = self._telnet.read_very_eager().decode(encoding='UTF-8', errors='replace')
            tmp = self._telnet.expect(
                [
                    Pattern.nebyteFlag.value, 
                    Pattern.pwdChangebyteFlag.value, 
                    Pattern.morebyteFlag.value, 
                    Pattern.continuebyteFlag.value, 
                    Pattern.loginbyteFlag.value, 
                    Pattern.passordbyteFlag.value, 
                    Pattern.firstSshbyteFlag.value, 
                    Pattern.yes_no_byteFlag.value, 
                    Pattern.Y_N_byteFlag.value, 
                    Pattern.Y_N_C_byteFlag.value
                ], 
                timeout=interval
            )[2].decode(encoding='UTF-8', errors='replace')
            #time.sleep(0.5)
            data = tmp.split('\n')
            stdout += tmp
        return stdout

    def run(self, cmds, interval):
        res, stdout = 'Below commands may be wrong:\n', ''
        stdout += self.send_command(' ', interval)
        if self._print:
            print(stdout)
        for cmd in cmds.split('\n'):
            if cmd.strip():
                stdout_temp = self.send_command(cmd, interval)
                stdout += stdout_temp
                for line in stdout_temp.split('\n'):
                    if self._print:
                        print(line)

                if Pattern.neErrorFlag.value.search(stdout_temp):
                    res += (cmd + '\n')

        if res == 'Below commands may be wrong:\n':
            res = 'All commands are executed perfectly'
        else:
            res = res.strip() + '$%^&'
        return res, stdout

    def close(self):
        self._telnet.write(b'exit\n')

